```mermaid
classDiagram
    class Note {
        +Integer id
        +String title
        +String content
        +DateTime created_at
        +DateTime updated_at
        +__str__() String
    }

    class NoteListView {
        +model: Note
        +template_name: String
        +context_object_name: String
        +get_queryset()
    }

    class NoteDetailView {
        +model: Note
        +template_name: String
    }

    class NoteCreateView {
        +model: Note
        +fields: List
        +success_url: String
    }

    class NoteUpdateView {
        +model: Note
        +fields: List
        +success_url: String
    }

    class NoteDeleteView {
        +model: Note
        +success_url: String
    }

    NoteListView ..> Note : uses
    NoteDetailView ..> Note : uses
    NoteCreateView ..> Note : creates
    NoteUpdateView ..> Note : updates
    NoteDeleteView ..> Note : deletes
```
