# CRUD Matrix - Task Manager (Sticky Notes)

| CRUD Operation | Use Case | Django View Class | HTTP Method | Database Operation |
| :--- | :--- | :--- | :--- | :--- |
| **Create** | Create New Note | `NoteCreateView` | POST | `INSERT` |
| **Read** | View Note List | `NoteListView` | GET | `SELECT` |
| **Read** | View Note Detail | `NoteDetailView` | GET | `SELECT` |
| **Update** | Edit Existing Note | `NoteUpdateView` | POST | `UPDATE` |
| **Delete** | Delete Note | `NoteDeleteView` | POST | `DELETE` |
