```mermaid
sequenceDiagram
    participant User
    participant Browser
    participant View as "Django View"
    participant Model as "Note Model"
    participant DB as "SQLite File"

    %% Create Note
    User->>Browser: Fill Create Form & Submit
    Browser->>View: POST /notes/create/
    View->>Model: Create Note Instance
    Model->>DB: INSERT INTO notes_note...
    DB-->>Model: Success
    Model-->>View: Saved Instance
    View-->>Browser: Redirect to Note List

    %% Read Note
    User->>Browser: Request Note List
    Browser->>View: GET /notes/
    View->>Model: objects.all()
    Model->>DB: SELECT * FROM notes_note
    DB-->>Model: Return Data
    Model-->>View: QuerySet
    View-->>Browser: Render HTML with Notes

    %% Update Note
    User->>Browser: Edit Form & Submit
    Browser->>View: POST /notes/<id>/update/
    View->>Model: Retrieve & Update Instance
    Model->>DB: UPDATE notes_note SET...
    DB-->>Model: Success
    View-->>Browser: Redirect to Note List

    %% Delete Note
    User->>Browser: Confirm Delete
    Browser->>View: POST /notes/<id>/delete/
    View->>Model: Retrieve Instance
    Model->>DB: DELETE FROM notes_note WHERE...
    DB-->>Model: Success
    View-->>Browser: Redirect to Note List
```
