# Design Diagrams

This folder contains the design diagrams for the Sticky Notes application.

- **Class Diagram**: Shows the `Note` model and its relationships.
- **Sequence Diagram**: Illustrates the flow of creating, updating, and deleting notes.
- **Use Case Diagram**: Depicts the user interactions with the system.

*(Note: These are placeholders. Actual diagrams would be image files or PDFs.)*
