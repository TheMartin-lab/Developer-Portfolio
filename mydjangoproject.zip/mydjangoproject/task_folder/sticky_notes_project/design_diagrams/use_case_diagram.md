```mermaid
usecaseDiagram
    actor User as "User"
    
    package "Task Manager (Sticky Notes)" {
        usecase "Create Note" as UC1
        usecase "View Note List" as UC2
        usecase "View Note Detail" as UC3
        usecase "Update Note" as UC4
        usecase "Delete Note" as UC5
    }

    User --> UC1
    User --> UC2
    User --> UC3
    User --> UC4
    User --> UC5
```
