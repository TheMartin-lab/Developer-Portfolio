from django.test import TestCase, Client
from django.urls import reverse
from .models import Note

class NoteModelTest(TestCase):
    def test_note_creation(self):
        note = Note.objects.create(title="Test Note", content="Test Content")
        self.assertEqual(str(note), "Test Note")
        self.assertTrue(isinstance(note, Note))

class NoteViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.note = Note.objects.create(title="Existing Note", content="Existing Content")
        self.list_url = reverse('note-list')
        self.create_url = reverse('note-create')
        self.detail_url = reverse('note-detail', args=[self.note.pk])
        self.update_url = reverse('note-update', args=[self.note.pk])
        self.delete_url = reverse('note-delete', args=[self.note.pk])

    def test_note_list_view(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Existing Note")
        self.assertTemplateUsed(response, 'notes/note_list.html')

    def test_note_detail_view(self):
        response = self.client.get(self.detail_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Existing Note")
        self.assertContains(response, "Existing Content")
        self.assertTemplateUsed(response, 'notes/note_detail.html')

    def test_note_create_view(self):
        response = self.client.post(self.create_url, {
            'title': 'New Note',
            'content': 'New Content'
        })
        # Should redirect after successful creation
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Note.objects.count(), 2)
        new_note = Note.objects.last()
        self.assertEqual(new_note.title, 'New Note')

    def test_note_update_view(self):
        response = self.client.post(self.update_url, {
            'title': 'Updated Note',
            'content': 'Updated Content'
        })
        self.assertEqual(response.status_code, 302)
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Note')
        self.assertEqual(self.note.content, 'Updated Content')

    def test_note_delete_view(self):
        response = self.client.post(self.delete_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Note.objects.count(), 0)
