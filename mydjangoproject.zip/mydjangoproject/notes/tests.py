from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from .models import Note
import datetime

class NoteModelTest(TestCase):
    def test_note_creation(self):
        """Test that a note can be created with valid attributes."""
        note = Note.objects.create(title="Test Note", content="Test Content")
        self.assertEqual(str(note), "Test Note")
        self.assertTrue(isinstance(note, Note))
        # Check that timestamps are set
        self.assertIsNotNone(note.created_at)
        self.assertIsNotNone(note.updated_at)

    def test_note_update_timestamp(self):
        """Test that updated_at changes when a note is modified."""
        note = Note.objects.create(title="Original Title", content="Original Content")
        original_updated_at = note.updated_at
        
        # Ensure some time passes or just rely on logic, but for tests usually fast.
        # We modify and save
        note.title = "New Title"
        note.save()
        
        # Refresh from DB
        note.refresh_from_db()
        self.assertNotEqual(note.updated_at, original_updated_at)
        self.assertTrue(note.updated_at > original_updated_at)

    def test_title_max_length(self):
        """Test that title respects max_length constraint (at model level validation)."""
        long_title = "a" * 201
        note = Note(title=long_title, content="Content")
        # SQLite doesn't enforce varchar length on insert, but Django's full_clean() does
        from django.core.exceptions import ValidationError
        with self.assertRaises(ValidationError):
            note.full_clean()

class NoteViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.note = Note.objects.create(title="Existing Note", content="Existing Content")
        self.list_url = reverse('note-list')
        self.create_url = reverse('note-create')
        self.detail_url = reverse('note-detail', args=[self.note.pk])
        self.update_url = reverse('note-update', args=[self.note.pk])
        self.delete_url = reverse('note-delete', args=[self.note.pk])

    def test_note_list_view(self):
        """Test the list view returns 200 and contains the note."""
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Existing Note")
        self.assertTemplateUsed(response, 'notes/note_list.html')
        self.assertIn('notes', response.context)
        
    def test_note_list_empty(self):
        """Test the list view when no notes exist."""
        Note.objects.all().delete()
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, "Existing Note")
        self.assertEqual(len(response.context['notes']), 0)

    def test_note_detail_view(self):
        """Test the detail view returns 200 and correct content."""
        response = self.client.get(self.detail_url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Existing Note")
        self.assertContains(response, "Existing Content")
        self.assertTemplateUsed(response, 'notes/note_detail.html')
        self.assertEqual(response.context['note'], self.note)

    def test_note_create_view_get(self):
        """Test that the create view renders the form correctly on GET."""
        response = self.client.get(self.create_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')
        self.assertIn('form', response.context)

    def test_note_create_view_post_success(self):
        """Test creating a new note via POST."""
        response = self.client.post(self.create_url, {
            'title': 'New Note',
            'content': 'New Content'
        })
        # Should redirect after successful creation
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, self.list_url)
        self.assertEqual(Note.objects.count(), 2)
        new_note = Note.objects.last()
        self.assertEqual(new_note.title, 'New Note')

    def test_note_update_view_get(self):
        """Test that the update view renders the form with existing data."""
        response = self.client.get(self.update_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')
        self.assertContains(response, 'value="Existing Note"') # Check if value is pre-filled

    def test_note_update_view_post_success(self):
        """Test updating an existing note via POST."""
        response = self.client.post(self.update_url, {
            'title': 'Updated Note',
            'content': 'Updated Content'
        })
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, self.list_url)
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, 'Updated Note')
        self.assertEqual(self.note.content, 'Updated Content')

    def test_note_delete_view_get(self):
        """Test that the delete confirmation page renders."""
        response = self.client.get(self.delete_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_confirm_delete.html')
        self.assertContains(response, "Are you sure you want to delete")

    def test_note_delete_view_post_success(self):
        """Test deleting a note via POST."""
        response = self.client.post(self.delete_url)
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, self.list_url)
        self.assertEqual(Note.objects.count(), 0)

    def test_note_create_invalid_empty_title(self):
        """Test validation: cannot create note with empty title."""
        response = self.client.post(self.create_url, {
            'title': '',
            'content': 'Content without title'
        })
        self.assertEqual(response.status_code, 200)  # Should return to form
        form = response.context['form']
        self.assertTrue(form.errors)
        self.assertIn('title', form.errors)
        self.assertEqual(form.errors['title'], ['This field is required.'])
        self.assertEqual(Note.objects.count(), 1) # Still only the initial note

    def test_note_update_invalid_empty_title(self):
        """Test validation: cannot update note to have empty title."""
        response = self.client.post(self.update_url, {
            'title': '',
            'content': 'Updated Content'
        })
        self.assertEqual(response.status_code, 200) # Should return to form
        form = response.context['form']
        self.assertTrue(form.errors)
        self.assertIn('title', form.errors)
        self.assertEqual(form.errors['title'], ['This field is required.'])
        self.note.refresh_from_db()
        self.assertEqual(self.note.title, "Existing Note")

    def test_note_404(self):
        """Test accessing non-existent notes returns 404."""
        invalid_id = 999
        urls = [
            reverse('note-detail', args=[invalid_id]),
            reverse('note-update', args=[invalid_id]),
            reverse('note-delete', args=[invalid_id]),
        ]
        for url in urls:
            response = self.client.get(url)
            self.assertEqual(response.status_code, 404)
