from django.db import models

class Shoe(models.Model):
    country = models.CharField(max_length=50)
    code = models.CharField(max_length=20)
    product = models.CharField(max_length=100)
    cost = models.IntegerField()
    quantity = models.IntegerField()

    def __str__(self):
        return f"{self.product} ({self.code})"
