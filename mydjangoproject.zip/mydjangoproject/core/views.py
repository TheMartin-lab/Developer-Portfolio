from django.shortcuts import render
from .models import Shoe

def home(request):
    return render(request, 'core/home.html')

def inventory_list(request):
    shoes = Shoe.objects.all()
    return render(request, 'core/inventory/list.html', {'shoes': shoes})
