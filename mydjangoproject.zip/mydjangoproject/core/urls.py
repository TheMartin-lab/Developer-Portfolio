from django.urls import path
from .views import home, inventory_list

urlpatterns = [
    path('', home, name='home'),
    path('inventory/', inventory_list, name='inventory'),
]
